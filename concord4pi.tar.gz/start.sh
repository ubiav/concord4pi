#!/bin/bash

cd /opt/concord4pi

java -Djava.util.logging.SimpleFormatter.format="%1\$tY-%1\$tm-%1\$td %1\$tH:%1\$tM:%1\$tS %4\$-6s %5\$s%6\$s%n" -cp lib/jSerialComm-1.3.11.jar:lib/jetty-all-9.4.5.v20170502-uber.jar:concord4pi.jar:lib/org.eclipse.paho.client.mqttv3-1.1.1.jar concord4pi.concord4pi 
